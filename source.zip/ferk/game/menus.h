#ifndef GAME_MENUS_H
#define GAME_MENUS_H


#include "../core/gba.h"
#include "../core/types.h"
#include "../core/core.h"
#include "../core/menu_screens.h"




#endif

